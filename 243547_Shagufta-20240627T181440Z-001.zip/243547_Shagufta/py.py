#!/usr/bin/python

 #Entrypoint 2.x
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").getOrCreate()

# On yarn:
# spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSup$
# specify .master("yarn")

sc = spark.sparkContext

import pyspark.sql.functions as f
file_path='file:///home/talentum/spark_auto/whitehouse_visits.txt'

df=spark.read.text(file_path)

df=df.filter(df.value.contains('POTUS'))

df=df.withColumn('updated',f.split(df.value,','))

df=df.withColumn('lastname',df.updated.getItem(0))
df=df.withColumn('firstname',df.updated.getItem(1))
df=df.withColumn('time_of_arrival',df.updated.getItem(6))
df=df.withColumn('appt_time',df.updated.getItem(11))
df=df.withColumn('location',df.updated.getItem(21))
df=df.withColumn('comments',df.updated.getItem(25))

df=df.drop('value','updated')
df.drop('updated')
df.coalesce(1).write.saveAsTable("output_wh_visit")
