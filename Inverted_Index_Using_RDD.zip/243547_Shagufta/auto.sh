#Author: Shagufta Nadaf
#Date of Creation:21-06-2024
#Date of Modification:21-06-2024
#Usage: ./auto.sh
#!/bin/bash
echo "--------------------Start-------------------"
rm -R invert_output
source unset.sh
spark-submit invertauto.py
hdfs dfs -cat /user/hive/warehouse/hortonworks_output/part-00000
echo "--------------------DONE--------------------"
