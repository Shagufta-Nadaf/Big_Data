#!/usr/bin/python

#Entrypoint 2.x
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()

# On yarn:
# spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().master("yarn").getOrCreate()
# specify .master("yarn")

sc = spark.sparkContext
file_path="file:///home/talentum/shagufta/auto2_spark/243547_Shagufta/hortonworks.txt"

RDD=sc.textFile(file_path)
RDD.collect()

def invert(data):
    split_data=data.split(',')
    key_data=split_data[0]
    val_data=split_data[1:]
    return [(i,key_data) for i in val_data] 
result=RDD.flatMap(lambda data:invert(data)).groupByKey().mapValues(lambda x:','.join(set(x)))

result.coalesce(1).saveAsTextFile("file:///home/talentum/shagufta/auto2_spark/243547_Shagufta/invert_output")
#result.saveAsTextFile("/user/hive/warehouse/inverted_out")
