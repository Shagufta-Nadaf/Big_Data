#!/bin/bash
#Author:Shagufta Nadaf
#Date of creation: 19-6-2024
#Modification Date:21-6-2024


echo "Welcome..."
hdfs dfs -rm -R /user/hive/warehouse/whitehouse_visits.txt
hdfs dfs -rm -R /user/hive/warehouse/wh_visits
hdfs dfs -put whitehouse_visits.txt /user/hive/warehouse/
source unset.sh
spark-submit auto.py
hive -f auto.hive
hive -e 'select * from wh_visits limit 10'
echo "Thank YOu..."
