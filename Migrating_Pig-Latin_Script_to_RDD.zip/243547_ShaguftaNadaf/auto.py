#!/usr/bin/python

#Entrypoint 2.x
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()

# On yarn:
# spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().master("yarn").getOrCreate()
# specify .master("yarn")

sc = spark.sparkContext


file_path = "file:///home/talentum/shagufta/auto_spark/whitehouse_visits.txt"
inputRDD=sc.textFile(file_path).map(lambda x:x.split(",")).filter(lambda x:'POTUS' in x[19]).map(lambda x:[x[0],x[1],x[6],x[11],x[19],x[21],x[25]])

inputRDD.map(lambda x:','.join(x)).coalesce(1).saveAsTextFile("/user/hive/warehouse/wh_visits")

